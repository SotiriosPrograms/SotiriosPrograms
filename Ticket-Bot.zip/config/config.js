module.exports = {
  clientId: "1108457684547666040", // The id of the discord bot
  guildId: "1105753378761474048", // The id of the discord server
  mainColor: "f6c42f", // The hex color of the embeds by default
  lang: "main", // If you want to set english please set "main"


  openTicketChannelId: "1105786320837689394", // The id of the channel where the message to create a ticket will be sent
  ticketTypes: [ // You have a limit of 25 types (the limit of Discord)
    {
      codeName: "category-one", // The name need to be in lowercase
      name: "Commande Shop", // The name that will be displayed in the ticket
      emoji: "<:application:954276352746471444>", // The emoji of the type (can be blank)
      color: "", // Can be a hex color or blank to use the main color
      categoryId: "1105789376006455366", // The category id where the tickets will be created
      customDescription: "Merci de respecter le schema de commande.\n\nReason: REASON", // The custom description of the ticket type (set to blank to use the default description)
      askReason: true // If the bot should ask the reason of the ticket
    },
    {
      codeName: "category-two", // The name need to be in lowercase
      name: "Commande Entreprise", // The name that will be displayed in the ticket
      emoji: "<a:a_moderation:953183975583670302>", // The emoji of the type (can be blank)
      color: "#f8312f", // Can be a hex color or blank to use the main color
      categoryId: "1105789376006455366", // The category id where the tickets will be created
      customDescription: "Please explain your report in detail. If you have any images, please attach them to your message.\n\nReason: REASON", // The custom description of the ticket type (set to blank to use the default description)
      askReason: false // If the bot should ask the reason of the ticket
    },
  ],
  ticketNameOption: "Ticket-TICKETCOUNT", // Here is all parameter: USERNAME, USERID, TICKETCOUNT
  rolesWhoHaveAccessToTheTickets: [
    "1108458563422146622","1105775161304686685",
  ], // Roles who can access to the tickets
  pingRoleWhenOpened: true,
  roleToPingWhenOpenedId: "1105775161304686685", // The role to ping when a ticket is opened
  logs: true,
  logsChannelId: "1105789673202274304", // The id of the channel where the logs will be sent
  claimButton: true,
  whoCanCloseTicket: "STAFFONLY", // STAFFONLY (roles configured at "rolesWhoHaveAccessToTheTickets") or EVERYONE
  closeButton: true, // If false the ticket can be closed only by doing /closes
  askReasonWhenClosing: true, // If false the ticket will be closed without asking the reason
  maxTicketOpened: 5 // The number of tickets the user can open while another one is already open. Set to 0 to unlimited
}
